abstract class HeaderNames {
  static String get authorization => 'Authoriation';
  static String get cookie => 'Cookie';
}
