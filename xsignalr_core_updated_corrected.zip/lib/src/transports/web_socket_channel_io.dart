
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:http/http.dart';
import 'package:http/io_client.dart';
import 'package:web_socket_channel/io.dart'; // Ensure compatibility with v3.x
import 'package:web_socket_channel/web_socket_channel.dart';

Future<WebSocketChannel> connect(
  Uri uri, {
  required BaseClient client,
}) async {
  final random = Random();

  final nonceData = Uint8List(16);
  for (var i = 0; i < 16; i++) {
    nonceData[i] = random.nextInt(256);
  }
  final nonce = base64.encode(nonceData);

  final wsUri = uri.replace(scheme: uri.scheme == 'wss' ? 'https' : 'http');

  final request = Request('GET', wsUri)
    ..headers.addAll({
      'Connection': 'Upgrade',
      'Upgrade': 'websocket',
      'Sec-WebSocket-Key': nonce,
      'Cache-Control': 'no-cache',
      'Sec-WebSocket-Version': '13',
    });

  final response = await client.send(request);
  final socket = await (response as IOStreamedResponse).detachSocket();

  final ws = WebSocket.fromUpgradedSocket(
    socket,
    serverSide: false,
  );

  return IOWebSocketChannel(ws); // Updated for clarity and explicit v3.x compliance
}
